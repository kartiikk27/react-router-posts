import React from 'react';

function About() {
  return <h2>This is the About Page</h2>;
}

export default About;
